package com.atgp.year3.atgp.service;

import com.atgp.year3.atgp.dto.request.LoginDto;
import com.atgp.year3.atgp.dto.request.UserDto;
import com.atgp.year3.atgp.dto.response.CreateUserResponse;
import com.atgp.year3.atgp.dto.response.LoginUserResponse;
import com.atgp.year3.atgp.entity.User;
import com.atgp.year3.atgp.mapper.UserMapper;
import com.atgp.year3.atgp.repository.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor(onConstructor = @__(@Autowired))
public class UserService {
    private UserRepository userRepository;

    private final UserMapper userMapper = UserMapper.INSTANCE;

    public CreateUserResponse postUser(UserDto dto){
        User toSaveUser = userMapper.toModel(dto);

        User savedPerson = userRepository.save(toSaveUser);
        return CreateUserResponse
                .builder()
                .message("User Created by Id: "+savedPerson.getId())
                .build();
    }

    public LoginUserResponse login(LoginDto dto){
        User user = userRepository.findByUserName(dto.getUserName());
        return LoginUserResponse.builder().token("").build();
    }

    public List<UserDto> listAll() {
        List<User> allPerson = userRepository.findAll();
        return allPerson.stream()
                .map(userMapper::toDto)
                .collect(Collectors.toList());
    }
}
