package com.atgp.year3.atgp.init;

import com.atgp.year3.atgp.entity.User;
import com.atgp.year3.atgp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;

@Component
public class StartApplication implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Transactional
    @Override
    public void run(String... args) throws Exception {
        User user = userRepository.findByUserName("admin");

        if(user == null){
            user = new User();
            user.setNome("carlos");
            user.setUsername("admin");
            user.setPassword("1234");
            user.setEmail("email@email.com");
            user.setPhone("");
            user.getRoles().add("MANAGER");
            userRepository.save(user);
        }

        user = userRepository.findByUserName("carlos");

        if(user == null){
            user = new User();
            user.setNome("carlos");
            user.setUsername("carlos");
            user.setPassword("1234");
            user.setEmail("email@email.com");
            user.setPhone("");
            user.getRoles().add("USER");
            userRepository.save(user);
        }
    }
}
