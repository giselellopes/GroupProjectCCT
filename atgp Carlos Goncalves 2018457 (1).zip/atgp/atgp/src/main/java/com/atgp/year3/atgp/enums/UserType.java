package com.atgp.year3.atgp.enums;

public enum UserType {

}
