package com.atgp.year3.atgp.mapper;

import com.atgp.year3.atgp.dto.request.UserDto;
import com.atgp.year3.atgp.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface  UserMapper {
    UserMapper INSTANCE = Mappers.getMapper(UserMapper.class);

    User toModel(UserDto userDto);
    UserDto toDto(User user);
}
