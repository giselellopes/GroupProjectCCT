package com.atgp.year3.atgp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtgpYear3Application {

	public static void main(String[] args) {
		SpringApplication.run(AtgpYear3Application.class, args);
	}

}
