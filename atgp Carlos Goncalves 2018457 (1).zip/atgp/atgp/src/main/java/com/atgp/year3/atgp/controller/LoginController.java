package com.atgp.year3.atgp.controller;

import com.atgp.year3.atgp.dto.request.LoginDto;
import com.atgp.year3.atgp.dto.request.UserDto;
import com.atgp.year3.atgp.dto.response.CreateUserResponse;
import com.atgp.year3.atgp.dto.response.LoginUserResponse;
import com.atgp.year3.atgp.service.UserService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("api/v1/login")
@AllArgsConstructor(onConstructor = @__(@Autowired))
public class LoginController {

    private UserService userService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public LoginUserResponse login(@RequestBody @Valid LoginDto dto){
        return userService.login(dto);
    }
}
