package com.atgp.year3.atgp.controller;

import com.atgp.year3.atgp.dto.request.UserDto;
import com.atgp.year3.atgp.dto.response.CreateUserResponse;
import com.atgp.year3.atgp.service.UserService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("api/v1/users")
@AllArgsConstructor(onConstructor = @__(@Autowired))
public class UserController {

    private UserService userService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyRole('MANAGER')")
    public CreateUserResponse postUser(@RequestBody @Valid UserDto dto){
        return userService.postUser(dto);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('MANAGER','USER')")
    public List<UserDto> listAll(){
        return userService.listAll();
    }
}
