package com.atgp.year3.atgp.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;

import javax.validation.constraints.Size;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {
    @NotEmpty
    @Size(min = 2, max = 100)
    private String username;

    @NotEmpty
    @Size(min = 2, max = 100)
    private String password;

    @NotEmpty
    private String email;

    private String nome;
    private String phone;
}
