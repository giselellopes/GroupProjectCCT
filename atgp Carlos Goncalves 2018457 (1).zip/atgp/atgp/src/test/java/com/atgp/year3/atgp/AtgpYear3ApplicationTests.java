package com.atgp.year3.atgp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtgpYear3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
