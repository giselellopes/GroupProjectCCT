const   express = require("express"),
        router = express.Router(),
        customerCtrl = require("./customer-controller");


router.post('/customer', customerCtrl.createCustomer);
router.get('/customer', customerCtrl.getCustomer);
router.get('/customer/:id', customerCtrl.getCustomer);


module.exports = router;